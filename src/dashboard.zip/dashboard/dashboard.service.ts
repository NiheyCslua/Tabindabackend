import { Injectable } from '@nestjs/common';
import { PrismaService } from 'src/prisma/prisma.service';

@Injectable()
export class DashboardService {
constructor(private prisma: PrismaService) {}

async getStats() {
const totalRevenue = await this.prisma.invoice.aggregate({
_sum: {
total: true,
},
where: {
status: 'PAID',
},
});

const totalInvoices = await this.prisma.invoice.count();

const paidInvoices = await this.prisma.invoice.count({
  where: { status: 'PAID' },
});

const unpaidInvoices = await this.prisma.invoice.count({
  where: { status: 'PENDING' },
});

const lowStockProducts = await this.prisma.product.findMany({
  where: {
    stock: {
      lte: 5,
    },
  },
});

return {
  revenue: totalRevenue._sum.total || 0,
  totalInvoices,
  paidInvoices,
  unpaidInvoices,
  lowStockProducts,
};

}
}
